"""Sample package for testing."""
__version__ = "1.0.0"
