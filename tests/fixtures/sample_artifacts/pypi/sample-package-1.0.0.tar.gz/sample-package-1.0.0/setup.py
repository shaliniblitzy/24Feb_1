from setuptools import setup, find_packages

setup(
    name='sample-package',
    version='1.0.0',
    packages=find_packages(),
    author='Test Author',
    author_email='test@example.com',
    description='A minimal sample package for testing',
    license='MIT',
)
